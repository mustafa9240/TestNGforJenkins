package Greek.Mustafa.TestBase;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class TestBase {

	@BeforeTest
	public void openDBconn(){
		
		System.out.println("DB Connection is open");
	}
	

	@AfterTest
	public void CloseDB(){
		
		System.out.println("DB Connection is CLosed ");
	}
}
