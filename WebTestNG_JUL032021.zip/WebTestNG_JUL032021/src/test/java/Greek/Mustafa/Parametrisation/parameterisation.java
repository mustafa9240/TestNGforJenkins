package Greek.Mustafa.Parametrisation;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class parameterisation {
	
	
	
	
	@Test(dataProvider="getData")
			
	public void doLogin(String Username,String Pwd)
	{
		System.out.println(Username);
		System.out.println( Pwd);		
	}
	
	@DataProvider
	public Object[][] getData()
	{
		
		Object[][] data=new Object[2][2];
		
		data[0][0]= "My First name ";
		data[0][1]= "My First PassCode ";
		
		data[1][0]= "My Second name ";
		data[1][1]= "My Second PassCode ";
		
	//	data[2][0]= "My Third name ";
	//	data[2][1]= "My Third PassCode ";
		
		return data;
		
		
	} 

}
