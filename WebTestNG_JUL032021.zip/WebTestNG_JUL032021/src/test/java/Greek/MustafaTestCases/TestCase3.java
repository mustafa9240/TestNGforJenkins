package Greek.MustafaTestCases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import static org.testng.Assert.fail;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Greek.Mustafa.TestBase.TestBase;

public class TestCase3  {
	
	
	@BeforeMethod 
	public void LaunchBrowser(){
		
		System.out.println("Chrome Launched");
	}
	
	@AfterMethod
	public void closebrowser(){
		System.out.println("Browser closed");
	}
	
	@Test (priority=1)
	public void doRegister(){
		System.out.println("Register");
		AssertJUnit.fail("Case Fail.");
	}
	
	@Test (priority=2,dependsOnMethods={"doRegister"})
	public void doLogin()
	{
		System.out.println("Loign Mesthod");
	}
	@Test (priority=3,alwaysRun=true)
	public void SearchItem()
	{
		System.out.println("Searching Mesthod");
	}
	@Test (priority=4,dependsOnMethods={"doRegister","doLogin"})
	public void AddinCart()
	{
		System.out.println("ADD-IN CART Mesthod");
	}
	@Test (priority=5,dependsOnMethods={"doRegister","doLogin"})
	public void Payment()
	{
		System.out.println("PAYMENT Mesthod");
	}
	
	
	
	
}
