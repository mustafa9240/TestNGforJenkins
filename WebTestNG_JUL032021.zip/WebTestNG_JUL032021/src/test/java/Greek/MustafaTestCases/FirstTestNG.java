package Greek.MustafaTestCases;

import org.testng.annotations.Test;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Greek.Mustafa.TestBase.TestBase;

public class FirstTestNG extends TestBase {
	
	
	@BeforeMethod 
	public void LaunchBrowser(){
		
		System.out.println("Chrome Launched");
	}
	
	@AfterMethod
	public void closebrowser(){
		System.out.println("Browser closed");
	}
	
	@Test (priority=1)
	public void doRegister(){
		System.out.println("Register");
	}
	
	@Test (priority=1)
	public void doLogin()
	{
		System.out.println("Loign Mesthod");
	}
}
