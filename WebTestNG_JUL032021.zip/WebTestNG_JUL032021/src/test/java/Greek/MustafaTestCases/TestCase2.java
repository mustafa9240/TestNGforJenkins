package Greek.MustafaTestCases;

import org.testng.annotations.Test;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Greek.Mustafa.TestBase.TestBase;

public class TestCase2 extends TestBase {
	
	
	SoftAssert  softssert;
	@Test
	public void ValidateTitle()
	{
	
		String ExpecpectedTitle="Reddiff.com";
		String ActualTitle="Redddiff.com";
		
		if(ActualTitle.equalsIgnoreCase(ExpecpectedTitle)){
			System.out.println("TestCase Pass");
		}else
		{
			System.out.println("TestCase Pass");
		}
		
		//Hard Assertion
		//Assert method for aactual test case pass and Fail and Report generation
		//	Assert.assertEquals(ActualTitle,ExpecpectedTitle);
		
	   //	Assert.assertEquals(10<5, "Logo is missing");
		
		//Asserion has two types Soft and hard assertion
		//soft assertion will procceed to next Step if one case/Condition fails
		//Hard assertion will not  procceed to next Step if one case/Condition fails
		
		//Soft Assertion
		softssert= new SoftAssert();		
		Assert.assertEquals(ActualTitle,ExpecpectedTitle);
		System.out.println("Assertion Case Failed");
		Assert.assertTrue(10<5, "Logo is missing");
		System.out.println("Validating Image");
		Assert.fail("Case Fail");
		System.out.println("End of testCase");
		//assert all will realease all memry and indicated the end of test cases //assertall is only for softasserts
		softssert.assertAll();
		
	}

}
